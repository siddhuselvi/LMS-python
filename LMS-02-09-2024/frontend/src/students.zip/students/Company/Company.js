// CompanyStatistic.js
import React from 'react';

const CompanyStatistic = () => {
  return (
    <div>
      <h2>Company Statistic</h2>
      <p>This is the Company Statistic page content.</p>
      <div>
      {/** <button onClick={disableSidebar}>Disable Sidebar</button>
        <button onClick={enableSidebar}>Enable Sidebar</button>*/}  
      </div>
    </div>
  );
};

export default CompanyStatistic;
